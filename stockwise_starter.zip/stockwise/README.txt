StockWise - starter code for the CSE 2100 semester project
==========================================================

StockWise is the stock and orders program that Regent Street Hardware (Georgetown)
has used since 2011. It works, mostly. Your team has one complaint to look into.

What is in this folder
  src/            the program (C source). This is where you work.
  data/           the shop's real stock list and two supplier files.
  orig/           an untouched copy of src/ for comparing. NEVER edit anything in here.
  tools/          make_patch.py writes your submission patch.
  Makefile        builds the program.
  stockwise.conf  settings (which stock list to open by default).

Build and run
  make                              build (needs gcc and make)
  ./stockwise                       open the shop's stock list (data/shop_live.csv)
  ./stockwise -d data/sample_small.csv    open the small sample list instead
  ./stockwise --nightly 100         the night-time batch run, 100 rounds

  Inside the program, type  help  to see the commands. Commands can also be
  piped in:   printf 'list\nquit\n' | ./stockwise

  Windows: use WSL (Ubuntu), or MSYS2/MinGW with gcc and make installed.
  macOS: install the command line tools (xcode-select --install).

Data files
  data/shop_live.csv        the shop's list, about 12,000 items
  data/sample_small.csv     60 items, handy for quick experiments
  data/supplier_sorted.csv  Demerara Supply's price file (30,000 rows)
  data/banks_paints.csv     Banks Paints' price file (20,000 rows)
  Use  import <file>  inside the program to bring in a supplier file.

Your patch
  When your fix is ready, run   make patch   (or: python3 tools/make_patch.py).
  It writes submission.patch: every change you made compared with orig/.
  Read it before you hand it in. Every line should be part of your fix.

Remember: you were assigned ONE complaint. The code has other quirks. Leave them
alone, even if you notice them, and mention them in your report instead.
