#!/usr/bin/env python3
"""
make_patch.py - writes submission.patch

It compares your working copy (src/, Makefile, stockwise.conf) with the untouched
copy in orig/ and writes every difference to submission.patch.
Run it from the stockwise folder:   make patch     (or:  python3 tools/make_patch.py)

Never edit anything inside orig/ - it is the reference your changes are measured against.
"""
import difflib, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ORIG = os.path.join(ROOT, "orig")
OUT = os.path.join(ROOT, "submission.patch")


def files_under(base):
    found = []
    for dirpath, dirnames, names in os.walk(base):
        for n in names:
            found.append(os.path.relpath(os.path.join(dirpath, n), base).replace(os.sep, "/"))
    return found


def read(path):
    try:
        with open(path, "rb") as f:
            raw = f.read()
        return raw.decode("utf-8").replace("\r\n", "\n").split("\n")
    except (OSError, UnicodeDecodeError):
        return None


def main():
    if not os.path.isdir(ORIG):
        sys.exit("orig/ folder not found. Run this from inside the stockwise folder you were given.")
    tracked = set(files_under(ORIG))
    for rel in files_under(ROOT):          # new files you created under src/
        if rel.startswith("src/"):
            tracked.add(rel)
    chunks, changed, added, removed = [], 0, 0, 0
    for rel in sorted(tracked):
        a = read(os.path.join(ORIG, rel)) if os.path.exists(os.path.join(ORIG, rel)) else []
        b = read(os.path.join(ROOT, rel)) if os.path.exists(os.path.join(ROOT, rel)) else []
        if a is None or b is None or a == b:
            continue
        old = "a/" + rel if os.path.exists(os.path.join(ORIG, rel)) else "/dev/null"
        new = "b/" + rel if os.path.exists(os.path.join(ROOT, rel)) else "/dev/null"
        diff = list(difflib.unified_diff(a, b, old, new, lineterm="", n=3))
        if not diff:
            continue
        changed += 1
        for line in diff:
            if line.startswith("+") and not line.startswith("+++"):
                added += 1
            elif line.startswith("-") and not line.startswith("---"):
                removed += 1
        chunks.append("\n".join(diff))
    with open(OUT, "w", newline="\n") as f:
        f.write("\n".join(chunks) + ("\n" if chunks else ""))
    print("Wrote submission.patch")
    print("  files changed: %d   lines added: %d   lines removed: %d" % (changed, added, removed))
    if changed == 0:
        print("  (no changes found - did you edit the files in src/ and not the ones in orig/?)")
    elif added + removed > 60:
        print("  That is a lot of changed lines for one bug. Check the diff: is every line part of your fix?")


if __name__ == "__main__":
    main()
