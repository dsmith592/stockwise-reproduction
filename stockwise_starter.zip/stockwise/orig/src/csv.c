/*
 * csv.c - reading and writing the stock files
 *
 * Format: sku,name,category,supplier,qty,reorder,price,restocked
 * Fields may be wrapped in double quotes (no escapes inside).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "csv.h"
#include "item.h"
#include "util.h"

/* splits line in place, returns number of fields */
int csv_split(char *line, char **fields, int max)
{
    int n = 0;
    char *p = line;

    while (n < max) {
        if (*p == '"') {
            p++;
            fields[n++] = p;
            while (*p && *p != '"')
                p++;
            if (*p == '"')
                *p++ = '\0';
            while (*p && *p != ',')
                p++;
        } else {
            fields[n++] = p;
            while (*p && *p != ',')
                p++;
        }
        if (*p == ',')
            *p++ = '\0';
        else
            break;
    }
    return n;
}

int csv_load_items(const char *path, Item **out, int *count)
{
    FILE *fp = fopen(path, "r");
    char line[LINE_MAX_LEN];
    char *f[16];
    Item *arr = NULL;
    Item it;
    int n = 0, cap = 0, nf;

    if (fp == NULL)
        return -1;
    while (fgets(line, sizeof line, fp) != NULL) {
        char *s = trim(line);

        if (s[0] == '\0' || s[0] == '#')
            continue;
        if (starts_with(s, "sku,"))
            continue;
        nf = csv_split(s, f, 16);
        if (item_from_fields(f, nf, &it) != 0)
            continue;               /* skip rows we cannot read */
        if (n == cap) {
            Item *bigger;

            cap = cap ? cap * 2 : 256;
            bigger = (Item *)realloc(arr, cap * sizeof(Item));
            if (bigger == NULL) {
                free(arr);
                fclose(fp);
                return -2;
            }
            arr = bigger;
        }
        arr[n++] = it;
    }
    fclose(fp);
    *out = arr;
    *count = n;
    return 0;
}

int csv_save_items(const char *path, const Item *items, int n)
{
    FILE *fp = fopen(path, "w");
    char money[32];
    int i;

    if (fp == NULL)
        return -1;
    fprintf(fp, "sku,name,category,supplier,qty,reorder,price,restocked\n");
    for (i = 0; i < n; i++) {
        format_money(items[i].price_cents, money);
        fprintf(fp, "%s,\"%s\",\"%s\",\"%s\",%d,%d,%s,%ld\n",
                items[i].sku, items[i].name, items[i].category,
                items[i].supplier, items[i].qty, items[i].reorder,
                money, items[i].restocked);
    }
    fclose(fp);
    return 0;
}
