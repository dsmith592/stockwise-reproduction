#ifndef REPORT_H
#define REPORT_H

#include "common.h"
#include "inventory.h"

void print_pages(const char *title, const Item *items, int n);
void report_list(Inventory *inv);
void report_by_name(Inventory *inv);
void report_by_category(Inventory *inv);
void report_by_stock(Inventory *inv);
void report_low_stock(Inventory *inv);
void report_by_restock(Inventory *inv);
void report_by_restock_legacy(Inventory *inv);
void report_summary(Inventory *inv);
void report_search(Inventory *inv, const char *text);

#endif
