/*
 * menu.c - the command prompt
 *
 * One command per line. Type "help" to see them.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "audit.h"
#include "config.h"
#include "csv.h"
#include "customer.h"
#include "export.h"
#include "inventory.h"
#include "item.h"
#include "menu.h"
#include "order.h"
#include "report.h"
#include "sort.h"
#include "util.h"

/* returns the next word and moves *sp past it; NULL when the line is empty */
static char *next_word(char **sp)
{
    char *s = *sp;
    char *w;

    while (*s == ' ' || *s == '\t')
        s++;
    if (*s == '\0') {
        *sp = s;
        return NULL;
    }
    w = s;
    while (*s && *s != ' ' && *s != '\t')
        s++;
    if (*s)
        *s++ = '\0';
    while (*s == ' ' || *s == '\t')
        s++;
    *sp = s;
    return w;
}

static void cmd_help(void)
{
    emit("Commands:\n");
    emit("  list                          show the whole stock list\n");
    emit("  find <sku>                    look up one item\n");
    emit("  search <text>                 find items by name\n");
    emit("  add <sku>,<name>,<category>,<supplier>,<qty>,<reorder>,<price>,<yyyymmdd>\n");
    emit("  import <file>                 bring in a supplier file\n");
    emit("  report name|category|stock|lowstock|restock|summary\n");
    emit("  customer add <name>,<phone>   |   customer list\n");
    emit("  order new <customer> <sku> <qty>   |   order list\n");
    emit("  audit                         recent changes\n");
    emit("  export <file>                 write a text stock sheet\n");
    emit("  save [file]                   write the stock list to disk\n");
    emit("  quit\n");
}

static void cmd_find(Inventory *inv, char *rest)
{
    char row[LINE_MAX_LEN];
    char *sku = next_word(&rest);
    int idx;

    if (sku == NULL) {
        emit("usage: find <sku>\n");
        return;
    }
    idx = find_by_sku(inv, sku);
    if (idx < 0) {
        emit("no such item: %s\n", sku);
        return;
    }
    item_format(&inv->items[idx], row, sizeof row);
    emit("found: %s\n", row);
}

static void cmd_add(Inventory *inv, const Config *cfg, char *rest)
{
    char *f[16];
    char row[LINE_MAX_LEN];
    Item it;
    int nf, r;

    nf = csv_split(rest, f, 16);
    if (nf == 7) {                      /* date left off: use today's stand-in */
        f[7] = "20260101";
        nf = 8;
    }
    if (item_from_fields(f, nf, &it) != 0) {
        emit("could not read that item (need 8 fields, see help)\n");
        return;
    }
    if (it.reorder == 0)
        it.reorder = cfg->low_stock_default;
    r = add_item(inv, &it);
    if (r == -2) {
        emit("duplicate SKU: %s\n", it.sku);
    } else if (r < 0) {
        emit("could not add item\n");
    } else {
        item_format(&it, row, sizeof row);
        emit("added: %s\n", row);
        audit_log("added %s", it.sku);
    }
}

static void cmd_import(Inventory *inv, char *rest)
{
    Item *rows = NULL;
    int n = 0, added, updated = 0;

    if (*rest == '\0') {
        emit("usage: import <file>\n");
        return;
    }
    if (csv_load_items(rest, &rows, &n) != 0) {
        emit("cannot read %s\n", rest);
        return;
    }
    quick_sort(rows, n, cmp_sku);
    added = inv_merge_sorted(inv, rows, n, &updated);
    free(rows);
    if (added < 0) {
        emit("import failed: out of memory\n");
        return;
    }
    emit("imported %d rows: %d new, %d updated\n", n, added, updated);
    audit_log("import %s (%d rows)", rest, n);
}

static void cmd_report(Inventory *inv, char *rest)
{
    char *w = next_word(&rest);

    if (w == NULL)
        emit("usage: report name|category|stock|lowstock|restock|summary\n");
    else if (strcmp(w, "name") == 0)
        report_by_name(inv);
    else if (strcmp(w, "category") == 0)
        report_by_category(inv);
    else if (strcmp(w, "stock") == 0)
        report_by_stock(inv);
    else if (strcmp(w, "lowstock") == 0)
        report_low_stock(inv);
    else if (strcmp(w, "restock") == 0)
        report_by_restock(inv);
    else if (strcmp(w, "summary") == 0)
        report_summary(inv);
    else
        emit("unknown report: %s\n", w);
}

static void cmd_customer(char *rest)
{
    char *w = next_word(&rest);
    char *f[4];
    int id;

    if (w != NULL && strcmp(w, "list") == 0) {
        customer_list();
    } else if (w != NULL && strcmp(w, "add") == 0) {
        if (csv_split(rest, f, 4) < 2) {
            emit("usage: customer add <name>,<phone>\n");
            return;
        }
        id = customer_add(trim(f[0]), trim(f[1]));
        if (id < 0)
            emit("customer table is full\n");
        else
            emit("customer %d added\n", id);
    } else {
        emit("usage: customer add <name>,<phone> | customer list\n");
    }
}

static void cmd_order(Inventory *inv, char *rest)
{
    char *w = next_word(&rest);
    char *cust, *sku, *qty;

    if (w != NULL && strcmp(w, "list") == 0) {
        order_list();
    } else if (w != NULL && strcmp(w, "new") == 0) {
        cust = next_word(&rest);
        sku = next_word(&rest);
        qty = next_word(&rest);
        if (cust == NULL || sku == NULL || qty == NULL) {
            emit("usage: order new <customer> <sku> <qty>\n");
            return;
        }
        order_new(inv, atoi(cust), sku, atoi(qty));
    } else {
        emit("usage: order new <customer> <sku> <qty> | order list\n");
    }
}

static int dispatch(Inventory *inv, const Config *cfg, char *line)
{
    char *rest = line;
    char *cmd = next_word(&rest);

    if (cmd == NULL)
        return 0;
    if (strcmp(cmd, "help") == 0)
        cmd_help();
    else if (strcmp(cmd, "list") == 0)
        report_list(inv);
    else if (strcmp(cmd, "find") == 0)
        cmd_find(inv, rest);
    else if (strcmp(cmd, "search") == 0)
        report_search(inv, rest);
    else if (strcmp(cmd, "add") == 0)
        cmd_add(inv, cfg, rest);
    else if (strcmp(cmd, "import") == 0)
        cmd_import(inv, rest);
    else if (strcmp(cmd, "report") == 0)
        cmd_report(inv, rest);
    else if (strcmp(cmd, "customer") == 0)
        cmd_customer(rest);
    else if (strcmp(cmd, "order") == 0)
        cmd_order(inv, rest);
    else if (strcmp(cmd, "audit") == 0)
        audit_show();
    else if (strcmp(cmd, "export") == 0) {
        if (*rest == '\0')
            emit("usage: export <file>\n");
        else if (export_report(inv, rest, cfg->shop) < 0)
            emit("cannot write %s\n", rest);
        else
            emit("wrote %s\n", rest);
    } else if (strcmp(cmd, "save") == 0) {
        if (inv_save(inv, rest) != 0)
            emit("save failed\n");
        else
            emit("saved\n");
    } else if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0)
        return 1;
    else
        emit("unknown command: %s (type help)\n", cmd);
    return 0;
}

void menu_run(Inventory *inv, const Config *cfg)
{
    char line[LINE_MAX_LEN];
    int tty = stdin_is_tty();

    for (;;) {
        if (tty) {
            printf("stockwise> ");
            fflush(stdout);
        }
        if (fgets(line, sizeof line, stdin) == NULL)
            break;
        if (dispatch(inv, cfg, trim(line)) == 1)
            break;
    }
}
