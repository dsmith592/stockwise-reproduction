#ifndef CONFIG_H
#define CONFIG_H

typedef struct {
    char shop[64];
    char data_file[256];
    int  low_stock_default;
    unsigned int sort_seed;
} Config;

void config_defaults(Config *c);
int  config_load(Config *c, const char *path);

#endif
