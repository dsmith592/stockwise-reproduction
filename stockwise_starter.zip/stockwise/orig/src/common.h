/*
 * common.h - shared types and constants for StockWise
 *
 * StockWise keeps the stock list for Regent Street Hardware.
 * Originally written 2011, extended by several people since.
 */
#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SHOP_NAME           "Regent Street Hardware"
#define STOCKWISE_VERSION   "2.3.1"

#define SKU_LEN    16
#define NAME_LEN   48
#define CAT_LEN    24
#define SUP_LEN    24

#define PAGE_SIZE      25      /* rows per printed page */
#define PAGE_ROWS      (PAGE_SIZE - 1)   /* data rows printed on each page */
#define LINE_MAX_LEN   512

/* special quantities used by the shop floor */
#define QTY_MADE_TO_ORDER  2147483647    /* we order it when a customer asks */
#define QTY_ON_HOLD        (-1000000000) /* supplier problem, cannot be sold */
/* ordinary negative quantities are back-orders: sold before they arrived */

typedef struct {
    char sku[SKU_LEN];
    char name[NAME_LEN];
    char category[CAT_LEN];
    char supplier[SUP_LEN];
    int  qty;
    int  reorder;
    long price_cents;
    long restocked;      /* yyyymmdd */
} Item;

typedef int (*CmpFn)(const void *, const void *);

#endif
