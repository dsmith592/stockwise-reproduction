#ifndef INVENTORY_H
#define INVENTORY_H

#include "common.h"

/*
 * The inventory array is kept in SKU order at all times.
 * find_by_sku() relies on that (it is a binary search).
 */
typedef struct {
    Item *items;
    int   count;
    int   cap;
    int   dirty;
    int   bulk;      /* while set, add_item() just appends (the loader sorts later) */
    char  path[256];
} Inventory;

void inv_init(Inventory *inv);
void inv_free(Inventory *inv);
void inv_ready(Inventory *inv);
int  inv_clone(Inventory *dst, const Inventory *src);
Item *inv_collect_low(Inventory *inv, int *m);
int  inv_load(Inventory *inv, const char *path);
int  inv_save(Inventory *inv, const char *path);
int  find_by_sku(const Inventory *inv, const char *sku);
int  add_item(Inventory *inv, const Item *it);
int  inv_merge_sorted(Inventory *inv, const Item *add, int n, int *updated);

#endif
