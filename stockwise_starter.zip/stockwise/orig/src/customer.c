/*
 * customer.c  --  trade customers (contractors etc)
 * (kept in a fixed table, nobody has more than 200)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "customer.h"
#include "util.h"

#define MAX_CUSTOMERS 200

typedef struct {
	int  id;
	char name[32];
	char phone[16];
	long credit_cents;
} Customer;

static Customer customers[MAX_CUSTOMERS];
static int ncust = 0;

void customer_seed(void)
{
	customer_add("Singh Contracting", "592-225-0141");
	customer_add("Georgetown Plumbing", "592-227-3310");
	customer_add("Ramdin Builders", "592-226-8875");
	customer_add("Cummings Electrical", "592-223-4102");
}

int customer_add(const char *name, const char *phone) {
	Customer *c;

	if (ncust >= MAX_CUSTOMERS)
		return -1;
	c = &customers[ncust];
	c->id = 100 + ncust + 1;
	strcpy(c->name, name);
	strcpy(c->phone, phone);
	c->credit_cents = 0;
	ncust++;
	return c->id;
}

const char *customer_name(int id) {
	int i;

	for (i = 0; i < ncust; i++)
		if (customers[i].id == id)
			return customers[i].name;
	return NULL;
}

void customer_list(void) {
	Customer sorted[MAX_CUSTOMERS];
	char line[128];
	int i, j;

	if (ncust == 0) {
		emit("no customers\n");
		return;
	}
	memcpy(sorted, customers, ncust * sizeof(Customer));
	for (i = 1; i < ncust; i++) {
		Customer key = sorted[i];

		j = i - 1;
		while (j >= 0 && ci_compare(sorted[j].name, key.name) > 0) {
			sorted[j + 1] = sorted[j];
			j--;
		}
		sorted[j + 1] = key;
	}
	for (i = 0; i < ncust; i++) {
		sprintf(line, "%d  %-24s %s", sorted[i].id, sorted[i].name, sorted[i].phone);
		emit("%s\n", line);
	}
	emit("(%d customers)\n", ncust);
}
