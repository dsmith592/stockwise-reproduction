/*
 * item.c - one stock item: parsing, printing, comparing
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "item.h"
#include "util.h"

int item_from_fields(char **f, int nf, Item *it)
{
    if (nf < 8)
        return -1;
    memset(it, 0, sizeof *it);
    str_copy(it->sku, trim(f[0]), SKU_LEN);
    str_copy(it->name, trim(f[1]), NAME_LEN);
    str_copy(it->category, trim(f[2]), CAT_LEN);
    str_copy(it->supplier, trim(f[3]), SUP_LEN);
    it->qty = atoi(f[4]);
    it->reorder = atoi(f[5]);
    it->price_cents = parse_money(f[6]);
    it->restocked = atol(f[7]);
    if (it->sku[0] == '\0')
        return -1;
    return 0;
}

/* one printable row; the SKU is always the first word on the line */
void item_format(const Item *it, char *buf, size_t cap)
{
    char price[24];
    char qtytxt[16];

    format_money(it->price_cents, price);
    if (it->qty == QTY_MADE_TO_ORDER)
        strcpy(qtytxt, "MTO");
    else if (it->qty == QTY_ON_HOLD)
        strcpy(qtytxt, "HOLD");
    else
        sprintf(qtytxt, "%d", it->qty);
    snprintf(buf, cap, "%-10s %-30.30s %-12.12s %6s %9s %8ld",
             it->sku, it->name, it->category, qtytxt, price, it->restocked);
}

/*
 * SKUs look like HW-1042: a text prefix, a dash, then a number.
 * Order by prefix first, then by the number as a number.
 */
int cmp_sku(const void *pa, const void *pb)
{
    const Item *a = (const Item *)pa;
    const Item *b = (const Item *)pb;
    const char *da = strchr(a->sku, '-');
    const char *db = strchr(b->sku, '-');
    int la, lb, r;
    long na, nb;

    if (da == NULL || db == NULL)
        return strcmp(a->sku, b->sku);
    la = (int)(da - a->sku);
    lb = (int)(db - b->sku);
    r = strncmp(a->sku, b->sku, la < lb ? la : lb);
    if (r != 0)
        return r;
    if (la != lb)
        return la - lb;
    na = sku_number(a->sku);
    nb = sku_number(b->sku);
    if (na != nb)
        return (na > nb) - (na < nb);
    return strcmp(a->sku, b->sku);
}

/* names A to Z, ignoring upper/lower case */
int cmp_name(const void *pa, const void *pb)
{
    const Item *a = (const Item *)pa;
    const Item *b = (const Item *)pb;
    int r;

    r = ci_compare(a->name, b->name);
    if (r != 0)
        return r;
    return strcmp(a->name, b->name);
}

/* sorts categories Z to A so Tools come first */
int cmp_category(const void *pa, const void *pb)
{
    const Item *a = (const Item *)pa;
    const Item *b = (const Item *)pb;

    return strcmp(a->category, b->category);
}

/* lowest stock first */
int cmp_qty(const void *pa, const void *pb)
{
    const Item *a = (const Item *)pa;
    const Item *b = (const Item *)pb;

    return cmp_int(a->qty, b->qty);
}

/* ops wants the most recently restocked at the top */
int cmp_restock(const void *pa, const void *pb)
{
    const Item *a = (const Item *)pa;
    const Item *b = (const Item *)pb;

    return (b->restocked > a->restocked) - (b->restocked < a->restocked);
}
