#ifndef CSV_H
#define CSV_H

#include "common.h"

int csv_split(char *line, char **fields, int max);
int csv_load_items(const char *path, Item **out, int *count);
int csv_save_items(const char *path, const Item *items, int n);

#endif
