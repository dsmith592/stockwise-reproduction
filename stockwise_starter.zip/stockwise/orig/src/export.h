#ifndef EXPORT_H
#define EXPORT_H

#include "inventory.h"

int export_report(const Inventory *inv, const char *path, const char *shop);

#endif
