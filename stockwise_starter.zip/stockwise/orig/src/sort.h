#ifndef SORT_H
#define SORT_H

#include "common.h"

#define SORT_BUBBLE     0
#define SORT_INSERTION  1
#define SORT_MERGE      2
#define SORT_QUICK      3
#define SORT_AUTO       4      /* let sort_items() choose */

/* lists this short are sorted with the simple sort; longer ones with merge sort */
#define SMALL_SORT_MAX  50000

void swap_items(Item *a, Item *b);
void bubble_sort(Item *a, int n, CmpFn cmp);
void insertion_sort(Item *a, int n, CmpFn cmp);
void merge_sort(Item *a, int n, CmpFn cmp);
void quick_sort(Item *a, int n, CmpFn cmp);
void sort_items(Item *a, int n, CmpFn cmp, int algo);
void sort_seed(unsigned int seed);

#endif
