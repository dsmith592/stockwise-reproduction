/*
 * sort.c - the sorting routines used by the reports and the importer
 *
 * All of them sort an array of Item with a qsort-style comparator.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "item.h"
#include "sort.h"

void swap_items(Item *a, Item *b)
{
    Item t = *a;

    *a = *b;
    *b = t;
}

void bubble_sort(Item *a, int n, CmpFn cmp)
{
    int i, j, swapped;

    for (i = 0; i < n - 1; i++) {
        swapped = 0;
        for (j = 0; j < n - 1 - i; j++) {
            if (cmp(&a[j], &a[j + 1]) > 0) {
                swap_items(&a[j], &a[j + 1]);
                swapped = 1;
            }
        }
        if (!swapped)
            break;
    }
}

void insertion_sort(Item *a, int n, CmpFn cmp)
{
    int i, j;
    Item key;

    for (i = 1; i < n; i++) {
        key = a[i];
        j = i - 1;
        while (j >= 0 && cmp(&a[j], &key) > 0) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = key;
    }
}

static void merge_runs(Item *a, Item *tmp, int lo, int mid, int hi, CmpFn cmp)
{
    int i = lo, j = mid, k = lo;

    while (i < mid && j < hi) {
        if (CMP_LEFT_FIRST(cmp(&a[i], &a[j])))
            tmp[k++] = a[i++];
        else
            tmp[k++] = a[j++];
    }
    while (i < mid)
        tmp[k++] = a[i++];
    while (j < hi)
        tmp[k++] = a[j++];
    memcpy(a + lo, tmp + lo, (hi - lo) * sizeof(Item));
}

static void msort_rec(Item *a, Item *tmp, int lo, int hi, CmpFn cmp)
{
    int mid;

    if (hi - lo < 2)
        return;
    mid = lo + (hi - lo) / 2;
    msort_rec(a, tmp, lo, mid, cmp);
    msort_rec(a, tmp, mid, hi, cmp);
    merge_runs(a, tmp, lo, mid, hi, cmp);
}

void merge_sort(Item *a, int n, CmpFn cmp)
{
    Item *tmp;

    if (n < 2)
        return;
    tmp = (Item *)malloc(n * sizeof(Item));
    if (tmp == NULL) {
        fprintf(stderr, "merge_sort: out of memory\n");
        exit(2);
    }
    msort_rec(a, tmp, 0, n, cmp);
    free(tmp);
}

/* small xorshift generator for choosing pivots; seeded from stockwise.conf */
static unsigned int rng_state = 1u;

void sort_seed(unsigned int seed)
{
    rng_state = seed;
}

static int rand_below(int n)
{
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return (int)(rng_state % (unsigned int)n);
}

void quick_sort(Item *a, int n, CmpFn cmp)
{
    int i, store;
    Item pivot;

    while (n > 1) {
        /* a random pivot keeps already-sorted input from being the worst case */
        swap_items(&a[0], &a[rand_below(n)]);
        pivot = a[0];
        store = 0;
        for (i = 1; i < n; i++) {
            if (cmp(&a[i], &pivot) < 0) {
                store++;
                swap_items(&a[i], &a[store]);
            }
        }
        swap_items(&a[0], &a[store]);
        /* recurse into the smaller part, loop on the larger one */
        if (store < n - store - 1) {
            quick_sort(a, store, cmp);
            a += store + 1;
            n -= store + 1;
        } else {
            quick_sort(a + store + 1, n - store - 1, cmp);
            n = store;
        }
    }
}

static int pick_algo(int n)
{
    return n <= SMALL_SORT_MAX ? SORT_BUBBLE : SORT_MERGE;
}

void sort_items(Item *a, int n, CmpFn cmp, int algo)
{
    if (algo == SORT_AUTO)
        algo = pick_algo(n);
    switch (algo) {
    case SORT_BUBBLE:
        bubble_sort(a, n, cmp);
        break;
    case SORT_INSERTION:
        insertion_sort(a, n, cmp);
        break;
    case SORT_QUICK:
        quick_sort(a, n, cmp);
        break;
    default:
        merge_sort(a, n, cmp);
        break;
    }
}
