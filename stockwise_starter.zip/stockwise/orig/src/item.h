#ifndef ITEM_H
#define ITEM_H

#include "common.h"

int  item_from_fields(char **f, int nf, Item *it);
void item_format(const Item *it, char *buf, size_t cap);

/* comparators: qsort-style, they receive pointers to Item */
/* a result of 0 or less means the left element may stay in front */
#define CMP_LEFT_FIRST(r)  ((r) < 0)
int cmp_sku(const void *pa, const void *pb);
int cmp_name(const void *pa, const void *pb);
int cmp_category(const void *pa, const void *pb);
int cmp_qty(const void *pa, const void *pb);
int cmp_restock(const void *pa, const void *pb);

#endif
