/*
 * main.c - StockWise entry point
 *
 *   stockwise [-d datafile]             interactive prompt
 *   stockwise [-d datafile] --nightly N batch run, N rounds
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "config.h"
#include "customer.h"
#include "inventory.h"
#include "menu.h"
#include "nightly.h"
#include "sort.h"
#include "util.h"

int main(int argc, char **argv)
{
    Inventory inv;
    Config cfg;
    const char *data = NULL;
    int nightly = 0, i;

    config_defaults(&cfg);
    config_load(&cfg, "stockwise.conf");
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0 && i + 1 < argc) {
            data = argv[++i];
        } else if (strcmp(argv[i], "--nightly") == 0 && i + 1 < argc) {
            nightly = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--version") == 0) {
            printf("StockWise %s\n", STOCKWISE_VERSION);
            return 0;
        } else {
            fprintf(stderr, "usage: stockwise [-d datafile] [--nightly N]\n");
            return 1;
        }
    }
    if (data == NULL)
        data = cfg.data_file;
    g_out = stdout;
    sort_seed(cfg.sort_seed);
    inv_init(&inv);
    if (inv_load(&inv, data) != 0) {
        fprintf(stderr, "cannot read %s\n", data);
        return 1;
    }
    customer_seed();
    emit("StockWise %s - %s\n", STOCKWISE_VERSION, cfg.shop);
    emit("loaded %d items from %s\n", inv.count, data);
    if (nightly > 0)
        nightly_run(&inv, nightly);
    else
        menu_run(&inv, &cfg);
    inv_free(&inv);
    return 0;
}
