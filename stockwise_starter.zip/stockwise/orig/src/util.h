#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>

/* all program output goes through emit() so the nightly job can discard it */
extern FILE *g_out;
extern long g_lines;
extern unsigned int g_hash;

void emit(const char *fmt, ...);
void emit_reset(void);

char *trim(char *s);
void str_copy(char *dst, const char *src, size_t cap);
int  starts_with(const char *s, const char *prefix);
int  ci_compare(const char *a, const char *b);
int  ci_contains(const char *hay, const char *needle);
long parse_money(const char *s);
void format_money(long cents, char *buf);
int  stdin_is_tty(void);
long sku_number(const char *sku);

/* three-way compare of two ints: negative, zero or positive */
static inline int cmp_int(int a, int b)
{
    return a - b;
}

#endif
