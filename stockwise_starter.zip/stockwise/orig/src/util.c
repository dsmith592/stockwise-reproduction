/*
 * util.c - small helpers used everywhere
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#ifdef _WIN32
#include <io.h>
#define IS_A_TTY(fp) _isatty(_fileno(fp))
#else
#include <unistd.h>
#define IS_A_TTY(fp) isatty(fileno(fp))
#endif
#include "common.h"
#include "util.h"

FILE *g_out = NULL;
long g_lines = 0;
unsigned int g_hash = 5381u;

void emit(const char *fmt, ...)
{
    char buf[2 * LINE_MAX_LEN];
    va_list ap;
    char *p;

    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    for (p = buf; *p; p++) {
        g_hash = g_hash * 33u + (unsigned char)*p;
        if (*p == '\n')
            g_lines++;
    }
    if (g_out != NULL)
        fputs(buf, g_out);
}

void emit_reset(void)
{
    g_lines = 0;
    g_hash = 5381u;
}

char *trim(char *s)
{
    char *end;

    while (*s == ' ' || *s == '\t')
        s++;
    end = s + strlen(s);
    while (end > s && (end[-1] == ' ' || end[-1] == '\t' ||
                       end[-1] == '\n' || end[-1] == '\r'))
        end--;
    *end = '\0';
    return s;
}

void str_copy(char *dst, const char *src, size_t cap)
{
    size_t n = strlen(src);

    if (n >= cap)
        n = cap - 1;
    memcpy(dst, src, n);
    dst[n] = '\0';
}

int starts_with(const char *s, const char *prefix)
{
    return strncmp(s, prefix, strlen(prefix)) == 0;
}

/* case-insensitive compare, same contract as strcmp */
int ci_compare(const char *a, const char *b)
{
    while (*a && *b) {
        int ca = (unsigned char)*a;
        int cb = (unsigned char)*b;

        if (ca != cb)
            return ca - cb;
        a++;
        b++;
    }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}

/* does hay contain needle, ignoring case? */
int ci_contains(const char *hay, const char *needle)
{
    size_t n = strlen(needle);

    if (n == 0)
        return 1;
    for (; *hay; hay++) {
        size_t i;

        for (i = 0; i < n && hay[i]; i++)
            if (tolower((unsigned char)hay[i]) != tolower((unsigned char)needle[i]))
                break;
        if (i == n)
            return 1;
    }
    return 0;
}

/* "12.50" -> 1250 */
long parse_money(const char *s)
{
    long whole = 0, frac = 0;
    int digits = 0;

    while (*s == ' ')
        s++;
    while (isdigit((unsigned char)*s))
        whole = whole * 10 + (*s++ - '0');
    if (*s == '.') {
        s++;
        while (isdigit((unsigned char)*s) && digits < 2) {
            frac = frac * 10 + (*s++ - '0');
            digits++;
        }
    }
    while (digits < 2) {
        frac *= 10;
        digits++;
    }
    return whole * 100 + frac;
}

void format_money(long cents, char *buf)
{
    sprintf(buf, "%ld.%02ld", cents / 100, cents % 100);
}

int stdin_is_tty(void)
{
    return IS_A_TTY(stdin);
}

/* the number part of a SKU: "HW-1042" -> 1042 */
long sku_number(const char *sku)
{
    if (strchr(sku, '-') == NULL)
        return 0;
    return strtol(sku, NULL, 10);
}
