/*
 * report.c - everything the shop prints
 *
 * Reports never change the inventory: they work on a copy.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "inventory.h"
#include "item.h"
#include "report.h"
#include "sort.h"
#include "util.h"

static Item *copy_items(const Inventory *inv)
{
    Item *c = (Item *)malloc((inv->count + 1) * sizeof(Item));

    if (c == NULL) {
        fprintf(stderr, "report: out of memory\n");
        return NULL;
    }
    memcpy(c, inv->items, inv->count * sizeof(Item));
    return c;
}

/* prints rows PAGE_SIZE at a time, with a header for each page */
void print_pages(const char *title, const Item *items, int n)
{
    int start, i, page = 0;
    char buf[LINE_MAX_LEN];

    if (n == 0) {
        emit("--- %s : empty ---\n", title);
        return;
    }
    for (start = 0; start < n; start += PAGE_SIZE) {
        page++;
        emit("--- %s : page %d ---\n", title, page);
        for (i = start; i < start + PAGE_ROWS && i < n; i++) {
            item_format(&items[i], buf, sizeof buf);
            emit("%s\n", buf);
        }
    }
    emit("(%d items)\n", n);
}

void report_list(Inventory *inv)
{
    print_pages("Inventory", inv->items, inv->count);
}

void report_by_name(Inventory *inv)
{
    Item *copy = copy_items(inv);

    if (copy == NULL)
        return;
    sort_items(copy, inv->count, cmp_name, SORT_AUTO);
    print_pages("By name", copy, inv->count);
    free(copy);
}

void report_by_category(Inventory *inv)
{
    Item *copy = copy_items(inv);

    if (copy == NULL)
        return;
    sort_items(copy, inv->count, cmp_category, SORT_MERGE);
    print_pages("By category", copy, inv->count);
    free(copy);
}

void report_by_stock(Inventory *inv)
{
    Item *copy = copy_items(inv);

    if (copy == NULL)
        return;
    sort_items(copy, inv->count, cmp_qty, SORT_MERGE);
    print_pages("By stock", copy, inv->count);
    free(copy);
}

/* items at or below their reorder level, lowest stock first */
void report_low_stock(Inventory *inv)
{
    Item *low;
    int m = 0;

    low = inv_collect_low(inv, &m);
    if (low == NULL)
        return;
    print_pages("Low stock", low, m);
    free(low);
}

void report_by_restock(Inventory *inv)
{
    Item *copy = copy_items(inv);

    if (copy == NULL)
        return;
    sort_items(copy, inv->count, cmp_restock, SORT_MERGE);
    print_pages("Restocked", copy, inv->count);
    free(copy);
}

/*
 * Old version of the restock report. Only the first 50 items, because that
 * is all the 2012 night-shift printout had room for. Still called from the
 * job table in nightly.c.
 */
void report_by_restock_legacy(Inventory *inv)
{
    Item *copy = copy_items(inv);
    int n = inv->count < 50 ? inv->count : 50;

    if (copy == NULL)
        return;
    sort_items(copy, n, cmp_restock, SORT_BUBBLE);
    print_pages("Restocked (legacy)", copy, n);
    free(copy);
}

void report_summary(Inventory *inv)
{
    int i, k, count = inv->count;
    int low = 0, made = 0, held = 0, ncat = 0;
    long long units = 0, value = 0;
    char cats[64][CAT_LEN];
    char money[40];
    Item *items = inv->items;

    for (i = 1; i <= count; i++) {      /* rows are numbered from 1 */
        Item *it = &items[i - 1];

        if (it->qty == QTY_MADE_TO_ORDER) {
            made++;
            continue;
        }
        if (it->qty == QTY_ON_HOLD) {
            held++;
            continue;
        }
        units += it->qty;
        value += (long long)it->qty * it->price_cents;
        if (it->qty <= it->reorder)
            low++;
    }
    for (i = 0; i < count; i++) {
        for (k = 0; k < ncat; k++)
            if (strcmp(cats[k], items[i].category) == 0)
                break;
        if (k == ncat && ncat < 64)
            str_copy(cats[ncat++], items[i].category, CAT_LEN);
    }
    sprintf(money, "%lld.%02lld", value / 100, value % 100);
    emit("=== Summary ===\n");
    emit("Items:               %d\n", count);
    emit("Categories:          %d\n", ncat);
    emit("Units in stock:      %lld\n", units);
    emit("Stock value:         %s\n", money);
    emit("Low-stock items:     %d\n", low);
    emit("Made to order:       %d\n", made);
    emit("On hold:             %d\n", held);
}

void report_search(Inventory *inv, const char *text)
{
    Item *hits;
    int i, m = 0;

    hits = (Item *)malloc((inv->count + 1) * sizeof(Item));
    if (hits == NULL)
        return;
    for (i = 0; i < inv->count; i++)
        if (ci_contains(inv->items[i].name, text))
            hits[m++] = inv->items[i];
    print_pages("Search", hits, m);
    free(hits);
}
