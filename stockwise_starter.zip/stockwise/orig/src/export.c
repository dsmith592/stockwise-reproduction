/*
 * export.c - plain text stock sheet for the accountant
 */
#include <stdio.h>
#include <string.h>
#include "common.h"
#include "export.h"
#include "item.h"
#include "util.h"

int export_report(const Inventory *inv, const char *path, const char *shop)
{
    FILE *fp = fopen(path, "w");
    char row[LINE_MAX_LEN];
    int i;

    if (fp == NULL)
        return -1;
    fprintf(fp, "%s - stock sheet\n", shop);
    fprintf(fp, "%d items\n\n", inv->count);
    for (i = 0; i < inv->count; i++) {
        item_format(&inv->items[i], row, sizeof row);
        fprintf(fp, "%s\n", row);
    }
    fclose(fp);
    return inv->count;
}
