#ifndef ORDER_H
#define ORDER_H

#include "inventory.h"

int  order_new(Inventory *inv, int cust, const char *sku, int qty);
void order_list(void);

#endif
