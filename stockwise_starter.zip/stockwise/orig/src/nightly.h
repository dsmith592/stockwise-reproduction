#ifndef NIGHTLY_H
#define NIGHTLY_H

#include "inventory.h"

int nightly_run(Inventory *inv, int rounds);

#endif
