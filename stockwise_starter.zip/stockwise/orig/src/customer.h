#ifndef CUSTOMER_H
#define CUSTOMER_H

void customer_seed(void);
int  customer_add(const char *name, const char *phone);
const char *customer_name(int id);
void customer_list(void);

#endif
