/*
 * config.c - reads stockwise.conf (key=value, # for comments)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "config.h"
#include "util.h"

void config_defaults(Config *c)
{
    str_copy(c->shop, SHOP_NAME, sizeof c->shop);
    str_copy(c->data_file, "data/shop_live.csv", sizeof c->data_file);
    c->low_stock_default = 5;
    c->sort_seed = 0;
}

int config_load(Config *c, const char *path)
{
    FILE *fp = fopen(path, "r");
    char line[LINE_MAX_LEN];

    if (fp == NULL)
        return -1;
    while (fgets(line, sizeof line, fp) != NULL) {
        char *s = trim(line);
        char *eq;
        char *key;
        char *val;

        if (s[0] == '#' || s[0] == '\0')
            continue;
        eq = strchr(s, '=');
        if (eq == NULL)
            continue;
        *eq = '\0';
        key = trim(s);
        val = trim(eq + 1);
        if (strcmp(key, "shop") == 0)
            str_copy(c->shop, val, sizeof c->shop);
        else if (strcmp(key, "data_file") == 0)
            str_copy(c->data_file, val, sizeof c->data_file);
        else if (strcmp(key, "low_stock_default") == 0)
            c->low_stock_default = atoi(val);
        else if (strcmp(key, "sort-seed") == 0)
            c->sort_seed = (unsigned int)strtoul(val, NULL, 10);
    }
    fclose(fp);
    return 0;
}
