#ifndef AUDIT_H
#define AUDIT_H

void audit_log(const char *fmt, ...);
void audit_show(void);

#endif
