#ifndef MENU_H
#define MENU_H

#include "config.h"
#include "inventory.h"

void menu_run(Inventory *inv, const Config *cfg);

#endif
