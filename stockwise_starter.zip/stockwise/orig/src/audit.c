/*
 * audit.c - remembers the last few things that changed stock
 */
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "audit.h"
#include "util.h"

#define AUDIT_KEEP 32
#define AUDIT_WIDTH 96

static char entries[AUDIT_KEEP][AUDIT_WIDTH];
static int total = 0;

void audit_log(const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsnprintf(entries[total % AUDIT_KEEP], AUDIT_WIDTH, fmt, ap);
    va_end(ap);
    total++;
}

void audit_show(void)
{
    int first = total > AUDIT_KEEP ? total - AUDIT_KEEP : 0;
    int i;

    if (total == 0) {
        emit("audit log is empty\n");
        return;
    }
    for (i = first; i < total; i++)
        emit("%4d  %s\n", i + 1, entries[i % AUDIT_KEEP]);
}
