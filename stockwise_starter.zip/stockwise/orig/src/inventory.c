/*
 * inventory.c - the in-memory stock list
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "csv.h"
#include "inventory.h"
#include "item.h"
#include "sort.h"
#include "util.h"

void inv_init(Inventory *inv)
{
    inv->items = NULL;
    inv->count = 0;
    inv->cap = 0;
    inv->dirty = 0;
    inv->bulk = 1;
    inv->path[0] = '\0';
}

void inv_free(Inventory *inv)
{
    inv_init(inv);
    free(inv->items);
}

/* the list is loaded and sorted: from now on add_item() keeps it in SKU order */
void inv_ready(Inventory *inv)
{
    inv->bulk = 0;
}

/* a private copy of the whole list, for jobs that must not disturb the live one */
int inv_clone(Inventory *dst, const Inventory *src)
{
    Item *p = (Item *)malloc((src->count + 1) * sizeof(Item));

    if (p == NULL)
        return -1;
    memcpy(p, src->items, src->count * sizeof(Item));
    *dst = *src;
    dst->items = p;
    dst->cap = src->count + 1;
    return 0;
}

/* the items at or below their reorder level, lowest stock first (caller frees) */
Item *inv_collect_low(Inventory *inv, int *m)
{
    Item *low = (Item *)malloc((inv->count + 1) * sizeof(Item));
    int i, k = 0;

    if (low == NULL)
        return NULL;
    sort_items(inv->items, inv->count, cmp_qty, SORT_MERGE);
    for (i = 0; i < inv->count; i++) {
        if (inv->items[i].qty <= inv->items[i].reorder)
            low[k++] = inv->items[i];
    }
    sort_items(low, k, cmp_qty, SORT_MERGE);
    *m = k;
    return low;
}

static int inv_grow(Inventory *inv)
{
    int ncap = inv->cap ? inv->cap * 2 : 256;
    Item *p = (Item *)realloc(inv->items, ncap * sizeof(Item));

    if (p == NULL)
        return -1;
    inv->items = p;
    inv->cap = ncap;
    return 0;
}

int inv_load(Inventory *inv, const char *path)
{
    Item *arr = NULL;
    int n = 0;

    if (csv_load_items(path, &arr, &n) != 0)
        return -1;
    inv->items = arr;
    inv->count = n;
    inv->cap = n;
    str_copy(inv->path, path, sizeof inv->path);
    /* keep the array in SKU order so find_by_sku can binary search */
    sort_items(inv->items, inv->count, cmp_sku, SORT_MERGE);
    inv->dirty = 0;
    return 0;
}

int inv_save(Inventory *inv, const char *path)
{
    if (path == NULL || path[0] == '\0')
        path = inv->path;
    if (csv_save_items(path, inv->items, inv->count) != 0)
        return -1;
    inv->dirty = 0;
    return 0;
}

/* index of the item, or -1 */
int find_by_sku(const Inventory *inv, const char *sku)
{
    Item key;
    int lo = 0, hi = inv->count - 1, mid, r;

    str_copy(key.sku, sku, SKU_LEN);
    while (lo <= hi) {
        mid = lo + (hi - lo) / 2;
        r = cmp_sku(&inv->items[mid], &key);
        if (r == 0)
            return mid;
        if (r < 0)
            lo = mid + 1;
        else
            hi = mid - 1;
    }
    return -1;
}

/* returns the new index, -1 on memory error, -2 if the SKU already exists */
int add_item(Inventory *inv, const Item *it)
{
    int pos;

    if (find_by_sku(inv, it->sku) >= 0)
        return -2;
    if (inv->count == inv->cap && inv_grow(inv) != 0)
        return -1;
    if (inv->bulk) {
        pos = inv->count;
    } else {
        /* find the slot that keeps the array in SKU order */
        int lo = 0, hi = inv->count, mid;

        while (lo < hi) {
            mid = lo + (hi - lo) / 2;
            if (cmp_sku(&inv->items[mid], it) < 0)
                lo = mid + 1;
            else
                hi = mid;
        }
        pos = lo;
    }
    memmove(&inv->items[pos + 1], &inv->items[pos],
            (inv->count - pos) * sizeof(Item));
    inv->items[pos] = *it;
    inv->count++;
    inv->dirty = 1;
    return pos;
}

/*
 * Merge a SKU-sorted array into the inventory in one pass.
 * Rows whose SKU already exists add their quantity to the existing item.
 * Returns the number of new items, or -1 on memory error.
 */
int inv_merge_sorted(Inventory *inv, const Item *add, int n, int *updated)
{
    Item *out;
    int i = 0, j = 0, k = 0, r, added = 0;

    *updated = 0;
    out = (Item *)malloc((inv->count + n + 1) * sizeof(Item));
    if (out == NULL)
        return -1;
    while (i < inv->count && j < n) {
        r = cmp_sku(&inv->items[i], &add[j]);
        if (r < 0) {
            out[k++] = inv->items[i++];
        } else if (r > 0) {
            out[k++] = add[j++];
            added++;
        } else {
            out[k] = inv->items[i++];
            if (out[k].qty >= 0 && out[k].qty < QTY_MADE_TO_ORDER)
                out[k].qty += add[j].qty;
            if (add[j].restocked > out[k].restocked)
                out[k].restocked = add[j].restocked;
            k++;
            j++;
            (*updated)++;
        }
    }
    while (i < inv->count)
        out[k++] = inv->items[i++];
    while (j < n) {
        out[k++] = add[j++];
        added++;
    }
    free(inv->items);
    inv->items = out;
    inv->count = k;
    inv->cap = k + 1;
    inv->dirty = 1;
    return added;
}
