/*
 * nightly.c - the after-hours batch run
 *
 * Runs the standard reports a number of times (the 2012 night shift used
 * it as a soak test) and throws the output away. Prints one summary line.
 */
#include <stdio.h>
#include "common.h"
#include "inventory.h"
#include "nightly.h"
#include "report.h"
#include "util.h"

typedef void (*ReportFn)(Inventory *);

typedef struct {
    const char *label;
    ReportFn    run;
} NightlyJob;

static const NightlyJob jobs[] = {
    { "category", report_by_category },
    { "stock",    report_by_stock },
    { "restock",  report_by_restock_legacy },
    { "summary",  report_summary },
};

#define NJOBS ((int)(sizeof jobs / sizeof jobs[0]))

int nightly_run(Inventory *inv, int rounds)
{
    FILE *saved = g_out;
    unsigned int hash;
    long lines;
    int r, j;

    if (rounds < 1)
        rounds = 1;
    g_out = NULL;                       /* discard sink */
    emit_reset();
    for (r = 0; r < rounds; r++) {
        Inventory work;

        /* every round works on its own copy, so the open session is left alone */
        if (inv_clone(&work, inv) != 0)
            return 1;
        for (j = 0; j < NJOBS; j++)
            jobs[j].run(&work);
        inv_free(&work);
    }
    hash = g_hash;
    lines = g_lines;
    g_out = saved;
    emit("nightly: rounds=%d items=%d lines=%ld hash=%08x\n",
         rounds, inv->count, lines, hash);
    return 0;
}
