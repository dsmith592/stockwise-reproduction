/*
 * order.c - counter orders for trade customers
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "audit.h"
#include "customer.h"
#include "inventory.h"
#include "order.h"
#include "util.h"

typedef struct Order {
	int id;
	int cust;
	char sku[SKU_LEN];
	int qty;
	long total_cents;
	char note[64];
	struct Order *next;
} Order;

static Order *order_head = NULL;
static Order *order_tail = NULL;
static int next_order_id = 1001;

int order_new(Inventory *inv, int cust, const char *sku, int qty)
{
	int idx;
	Item *it;
	Order *o;

	if (qty <= 0) {
		emit("quantity must be at least 1\n");
		return -1;
	}
	if (customer_name(cust) == NULL) {
		emit("no such customer: %d\n", cust);
		return -1;
	}
	idx = find_by_sku(inv, sku);
	if (idx < 0) {
		emit("no such item: %s\n", sku);
		return -1;
	}
	it = &inv->items[idx];
	if (it->qty == QTY_ON_HOLD) {
		emit("item is on hold: %s\n", sku);
		return -1;
	}
	if (it->qty != QTY_MADE_TO_ORDER) {
		if (it->qty < qty) {
			emit("not enough stock: %s has %d\n", sku, it->qty);
			return -1;
		}
		it->qty -= qty;
		inv->dirty = 1;
	}
	o = malloc(sizeof(Order));
	o->id = next_order_id++;
	o->cust = cust;
	strcpy(o->sku, sku);
	o->qty = qty;
	o->total_cents = it->price_cents * qty;
	sprintf(o->note, "%s x%d for %s", it->name, qty, customer_name(cust));
	o->next = NULL;
	if (order_tail == NULL)
		order_head = o;
	else
		order_tail->next = o;
	order_tail = o;
	audit_log("order %d placed for customer %d", o->id, cust);
	emit("order %d: %s\n", o->id, o->note);
	return o->id;
}

void order_list(void)
{
	Order *o;
	char money[32];
	int n = 0;

	for (o = order_head; o != NULL; o = o->next) {
		format_money(o->total_cents, money);
		emit("order %d  customer %d  %s x%d  total %s\n",
		     o->id, o->cust, o->sku, o->qty, money);
		n++;
	}
	emit("(%d orders)\n", n);
}
